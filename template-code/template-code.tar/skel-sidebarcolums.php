
<!-- LEFT -->
<body><div id="boxleft">
  <div class="row">
    <div class="column">TESTING-1left mi fa so la ti da</div>
    <div class="column">TESTING</div>
  </div></div>


<!-- RIGHT -->
  <div id="boxright">
    <div class="row">
      <div class="column">TESTING-1right do re mi fa so la ti do</div>
      <div class="column">TESTING</div>
    </div></div>
