<!-- ABOUT CONTENT -->
<center>
  <h5>A multi-language & machine learning capable searching solution that can fit in your pocket. </h5><h2><i>Eat The Sun!</i></h2>
 </br>
   <h5>The Black Hole project was started as a joke, and for fun. Over some conversations with friends they agreed to give a helping hand.
   The entire purpose of this project is to link logistical data processing with analytics and research.
   We want to provide data solutions to people that need to find, or process the information from what is needed, in a split second.
   Sometime around September 21st 2018, I indexed 40,000+ books on many subjects, the results of that, were not impressive.
   After two entire days fiddling around with the software, it finally started to spit out the information from the book at me.
   It does so almost stupidly, that is what makes it amazing, and fun. This project is a data black hole, the thing is...
   Nobody knows whats inside a black hole, they do not know what is inside of the libraries we are working with neither.
   But, all that being said, we plan to utilize ML (Machine Learning) to greatly improve this research and study technology.
   So, goes without saying, "a wise man once said, .. "
 </br></br></br></br>"He who has a lot of books cannot read." -Py </br></h5>
   <h3>"CHALLENGE ACCEPTED" -Diveyez</h3>
 </br></br>

<img src="images/bookchair.jpg"></img></center>
<!-- About Us -->
