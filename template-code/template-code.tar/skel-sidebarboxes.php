<!-- LEFT -->
<div id="boxleft">
  <div class="row">
    <div class="column">TESTING</div>
    <div class="column"></div>
    <div class="column"></div>
    <div class="column"></div>
    <div class="column"></div>
    <div class="column"></div>
    <div class="column"></div>
    <div class="column"></div>
  </div></div>


<!-- RIGHT -->
<div id="boxright">
  <div class="row">
    <div class="column">TESTING</div>
    <div class="column"></div>
    <div class="column"></div>
    <div class="column"></div>
    <div class="column"></div>
    <div class="column"></div>
    <div class="column"></div>
    <div class="column"></div>
  </div></div>
