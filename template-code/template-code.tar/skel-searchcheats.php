<!-- SEARCH CHEAT SHEET =P -->
      <div id="cheats">
      <b> The following is a sort of, cheat sheet for search queries.</b> <b> View the <a href="queries.php">Queries Explained</a> page for explainations.</b>
      <i>"phraseyouwish"</i> <i>"adam +laverne"</i> <i>"bitcoin $6000..$80000"</i></br> <i>"'MICHAEL'*'DOUGLAS'"</i> <i>"'-MICHAEL'*'-DOUGLAS'"</i></br>
      <i>"Something I Need To Find&hl.q=Something More Specific From That Document, Site, Etc. -*"</i></br></br><i>"Website.com:phrase/sentence" "booktitle:phrase/sentence"</i></br>
      <i>"website1.com site:website2.com"</i><i>"Medicine book:'Antibiotics'-*"</i></br><i>"DAY:DATE Monday:February 1, MONTH:YEAR '1790'&hl.q=sumreme court&-*"</i></br>
      <i>"Alcohol vs. Wine"</i><i>"DEFINE: 'whats on your mind'".</i></br><i>"How To book:'DEFINE: Home Made Solar Panels'-*"</i></br>
      <i>"DEFINE:DAY:DATE Monday:February 1, MONTH:YEAR '1790'&hl.q=sumreme court&-*"</i></br></div>
<!-- SEARCH CHEAT SHEET =P -->
