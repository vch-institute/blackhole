<!-- TOP CONTENT -->

			<body><div id="cont"><center>
										<a href="./"><img src="images/blackhole.png" height="275" width="300"></img></a></br>
										<plight>Welcome to Black Hole, What do you want to search for?</plight></br>

				<!-- TOP CONTENT -->
