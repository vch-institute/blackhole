<!-- GO BACK button -->
              <button onclick="goBack()">Go Back To Search</button>
              <script> function goBack() { window.history.back(); } </script>
<!-- GO BACK button -->
