<!-- FOOTER AREA -->
						<div id="footer"><center>
								<h5> <a href="https://github.com/diveyez/blackhole/">Black Hole</a> by <a href="https://github.com/diveyez/">Ricky 'Diveyez' N.</a></p>&copy; ® 2016-<?php echo date("Y"); ?></h5>
												<h5>Los Angeles, California <a href="https://r2nhosting.com">R2N Hosting Solutions</a></h5>
											</center></div>
